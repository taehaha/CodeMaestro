const GroupDetail = () => {
    return(<>그룹디테일 모달</>)
}

export default GroupDetail